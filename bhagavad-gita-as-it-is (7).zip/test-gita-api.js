try {
  const response = await fetch('https://bhagavadgitaapi.in/api/v1/chapters');
  if (response.ok) {
    const data = await response.json();
    console.log('Chapters API Success:', Array.isArray(data));
  } else {
    console.log('Chapters API Failed:', response.status);
  }
} catch (e) {
  console.log('Fetch error:', e.message || e);
}

try {
  const response = await fetch('https://bhagavadgitaapi.in/api/v1/chapters/12/verses/1');
  if (response.ok) {
    const data = await response.json();
    console.log('Single Verse API Success:', data);
  } else {
    console.log('Single Verse API Failed:', response.status);
  }
} catch (e) {
  console.log('Fetch error for single verse:', e.message || e);
}
