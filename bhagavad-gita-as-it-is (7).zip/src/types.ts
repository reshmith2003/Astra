/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type Language = 'en';

export interface MultilingualText {
  en: string;
  kn: string;
  hi: string;
  sa?: string;
}

export interface Chapter {
  id: number;
  name: MultilingualText; // e.g. "Arjuna Vishada Yoga"
  title: MultilingualText; // Translated title, e.g. "Arjuna's Grief"
  summary: MultilingualText;
  verseCount: number;
}

export interface Verse {
  chapterNumber: number;
  verseNumber: number;
  shloka: string;
  transliteration: MultilingualText;
  wordForWord: MultilingualText;
  translation: MultilingualText;
  purport: MultilingualText;
}

export interface GitaData {
  chapters: Chapter[];
  verses: {
    [key: string]: Verse; // key form: "chapterNumber_verseNumber" e.g., "1_1"
  };
}
