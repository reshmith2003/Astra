/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Language, Chapter } from '../types';
import { chapters } from '../gita-data';
import { uiTranslations } from '../translations';

interface ChaptersListProps {
  currentLang: Language;
  onChapterClick: (chapterId: number) => void;
}

export function ChaptersList({ currentLang, onChapterClick }: ChaptersListProps) {
  const t = uiTranslations[currentLang];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10" id="chapters-section">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between border-b-2 border-saffron-500/10 pb-5 mb-10">
        <div>
          <h3 className="text-2xl sm:text-3xl font-serif font-black text-gray-900 tracking-tight flex items-center gap-2">
            <span>{t.readChapters}</span>
          </h3>
          <p className="text-sm text-gray-500 mt-1 font-sans font-medium">
            18 Chapters • 700 Verses • Seamlessly Translated
          </p>
        </div>
      </div>

      {/* Grid of 18 Chapters */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8" id="chapters-grid">
        {chapters.map((ch) => (
          <div
            key={ch.id}
            onClick={() => onChapterClick(ch.id)}
            className="group relative bg-white rounded-2xl border border-saffron-200/50 hover:border-saffron-500 hover:shadow-xl hover:-translate-y-1 p-6 cursor-pointer overflow-hidden transition-all duration-300 flex flex-col justify-between glow-saffron"
            id={`chapter-card-${ch.id}`}
          >
            {/* Top Row with ID Badge and Verse Count */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <span className="text-xs font-mono font-bold uppercase tracking-wider text-saffron-600 bg-saffron-50 px-2.5 py-1 rounded-md">
                  {t.chapter} {ch.id}
                </span>
                <span className="text-xs font-serif font-semibold text-maroon-700 bg-maroon-50 px-2.5 py-1 rounded-md">
                  {ch.verseCount} {t.verses}
                </span>
              </div>

              {/* Title & Subtitle */}
              <h4 className="text-xl font-serif font-bold text-gray-900 group-hover:text-maroon-600 transition-colors mb-2">
                {ch.name[currentLang]}
              </h4>
              <p className="text-xs sm:text-sm font-sans font-medium text-saffron-700 border-l-2 border-saffron-400 pl-2 mb-3">
                {ch.title[currentLang]}
              </p>

              {/* Chapter Summary Text */}
              <p className="text-gray-600 text-xs sm:text-sm leading-relaxed line-clamp-3 group-hover:line-clamp-none transition-all duration-300">
                {ch.summary[currentLang]}
              </p>
            </div>

            {/* Read Button Footer */}
            <div className="mt-5 pt-4 border-t border-saffron-100/50 flex items-center justify-between text-xs font-bold text-maroon-600 group-hover:text-saffron-600 transition-colors">
              <span>EXPLORE VERSES</span>
              <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1.5 transition-transform" />
            </div>
          </div>
        ))}
      </div>

      {/* About Section */}
      <div className="mt-16 bg-white rounded-2xl border border-saffron-200/60 p-6 sm:p-8 shadow-sm flex flex-col md:flex-row items-center gap-6" id="about-gita-section">
        <div>
          <h4 className="text-lg font-serif font-bold text-gray-900 mb-1">{t.aboutGita}</h4>
          <p className="text-gray-600 text-sm leading-loose">
            {t.aboutGitaText}
          </p>
        </div>
      </div>
    </div>
  );
}
