/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, ChevronLeft, ChevronRight } from 'lucide-react';
import { Language, Verse, Chapter } from '../types';
import { uiTranslations } from '../translations';
import { staticVerses } from '../gita-data';

interface VerseViewProps {
  verse: Verse;
  chapter: Chapter;
  currentLang: Language;
  onBackToChapter: () => void;
  onPrevVerse: () => void;
  onNextVerse: () => void;
}

export function VerseView({
  verse,
  chapter,
  currentLang,
  onBackToChapter,
  onPrevVerse,
  onNextVerse,
}: VerseViewProps) {
  const t = uiTranslations[currentLang];
  const isKey = !!staticVerses[`${verse.chapterNumber}_${verse.verseNumber}`];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="verse-view-container">
      {/* Breadcrumbs & Back */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-saffron-100 pb-4 mb-8" id="verse-view-navheader">
        <button
          onClick={onBackToChapter}
          className="inline-flex items-center space-x-2 text-sm font-semibold text-maroon-700 hover:text-saffron-600 cursor-pointer transition-colors group"
          id="verse-back-btn"
        >
          <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" />
          <span>{t.backToChapter}</span>
        </button>

        {/* Current status bar */}
        <div className="text-xs sm:text-sm font-serif font-black text-gray-500 bg-saffron-50 px-3 py-1 rounded-md">
          {chapter.name[currentLang]} • {t.verse} {verse.chapterNumber}.{verse.verseNumber}
        </div>
      </div>

      {/* Main Responsive Grid Layout */}
      <div className="flex flex-col lg:flex-row gap-8 items-stretch" id="verse-split-layout">
        
        {/* Left Column: Traditional Sanskrit Shloka & Pronunciation */}
        <div className="w-full lg:w-[42%] flex flex-col" id="verse-left-pane">
          <div 
            className="flex-1 bg-white rounded-3xl border border-saffron-200 shadow-xl glow-saffron overflow-hidden p-6 sm:p-8 md:p-10 flex flex-col justify-center relative min-h-[400px]"
            id="verse-sacred-card"
          >
            {/* Saffron design highlight */}
            <div className="absolute top-0 inset-x-0 h-1 bg-saffron-500" />
            
            {/* Sanskrit Ornament Icon */}
            <div className="text-center mb-6 flex justify-center items-center space-x-2">
              <div className="h-0.5 w-8 bg-gradient-to-r from-transparent to-saffron-400" />
              <div className="w-8 h-8 rounded-full bg-maroon-50 text-maroon-700 flex items-center justify-center font-bold text-xs uppercase shadow-sm">ॐ</div>
              <div className="h-0.5 w-8 bg-gradient-to-l from-transparent to-saffron-400" />
            </div>

            {/* 1. Sanskrit Shloka Content */}
            <div className="text-center mb-8" id="shloka-sanskrit-content">
              <p className="font-devanagari text-xl sm:text-2xl md:text-3xl font-bold text-maroon-900 leading-double whitespace-pre-line tracking-wide">
                {verse.shloka}
              </p>
            </div>

            <div className="w-12 h-px bg-saffron-200 mx-auto mb-6" />

            {/* 2. Transliteration Section */}
            <div className="text-center" id="transliteration-section">
              <h4 className="text-[10px] font-mono font-bold text-saffron-700 uppercase tracking-widest mb-3">
                {t.transliterationLabel}
              </h4>
              <p className="mx-auto max-w-md font-serif text-base text-gray-700 italic whitespace-pre-line leading-relaxed">
                {verse.transliteration[currentLang]}
              </p>
            </div>
          </div>
        </div>

        {/* Right Column: Detailed Translations & Purport Commentary */}
        <div className="w-full lg:w-[58%] flex flex-col space-y-6" id="verse-right-pane">
          
          {/* 3. Word-by-Word Translation Card */}
          <div className="bg-white/60 backdrop-blur-sm border border-saffron-200/50 rounded-2xl p-6 shadow-sm relative" id="wordforword-section">
            <div className="flex justify-between items-center mb-3">
              <h4 className="text-[10px] font-mono font-bold text-saffron-700 uppercase tracking-widest">
                {t.wordForWordLabel}
              </h4>
            </div>

            <p className="text-gray-700 leading-loose font-sans text-sm sm:text-base">
              {verse.wordForWord[currentLang]}
            </p>
          </div>

          {/* 4. Translation Combined Card */}
          <div className="flex-1 bg-white border border-saffron-200/50 rounded-2xl p-6 sm:p-8 shadow-md flex flex-col relative" id="translation-purport-card">
            
            {/* Translation subsection */}
            <div className="flex-1 animate-fadeIn" id="translation-section">
              <div className="flex justify-between items-center mb-3">
                <h4 className="text-[10px] font-mono font-bold text-saffron-600 uppercase tracking-widest">
                  {t.translationLabel}
                </h4>
              </div>

              <div className="text-maroon-900 font-serif font-bold text-lg sm:text-xl leading-snug">
                {verse.translation[currentLang]}
              </div>
            </div>

          </div>

        </div>

      </div>

      {/* Primary Navigation Buttons (Bottom) */}
      <div className="flex items-center justify-between gap-4 mt-6" id="verse-bottom-nav">
        <button
          onClick={onPrevVerse}
          className="flex-1 flex items-center justify-center space-x-2 p-3 sm:p-4 rounded-xl text-xs sm:text-sm font-bold text-maroon-700 bg-white hover:bg-saffron-100/60 border border-saffron-200 transition-all cursor-pointer shadow-sm active:scale-95"
          id="btn-prev-verse"
        >
          <ChevronLeft className="w-5 h-5" />
          <span>{t.previousVerse}</span>
        </button>

        <button
          onClick={onNextVerse}
          className="flex-1 flex items-center justify-center space-x-2 p-3 sm:p-4 rounded-xl text-xs sm:text-sm font-bold text-white bg-maroon-500 hover:bg-maroon-600 transition-all cursor-pointer shadow-md active:scale-95"
          id="btn-next-verse"
        >
          <span>{t.nextVerse}</span>
          <ChevronRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
