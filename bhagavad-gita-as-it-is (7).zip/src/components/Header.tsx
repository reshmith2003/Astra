/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Menu, X, Sun, Search, Compass, BookOpen } from 'lucide-react';
import { Language } from '../types';
import { uiTranslations } from '../translations';

interface HeaderProps {
  currentLang: Language;
  onNavigate: (view: 'home' | 'chapter' | 'verse', chapterId?: number, verseId?: number) => void;
  activeView: string;
  onSearchToggle: () => void;
}

export function Header({
  currentLang,
  onNavigate,
  activeView,
  onSearchToggle,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const t = uiTranslations[currentLang];

  const handleNav = (view: 'home' | 'chapter' | 'verse', chId?: number, vId?: number) => {
    onNavigate(view, chId, vId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-spirit-bg/95 backdrop-blur-md border-b-2 border-saffron-500/20 shadow-sm" id="main-header">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo & Branding */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group"
            onClick={() => handleNav('home')}
            id="header-branding"
          >
            <div className="relative flex items-center justify-center w-11 h-11 rounded-full bg-gradient-to-br from-maroon-500 to-saffron-500 text-white shadow-md group-hover:rotate-12 transition-transform duration-300 shrink-0" id="round-header-logo-container">
              <Sun className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h1 className="text-xl sm:text-2xl font-serif font-bold text-maroon-500 tracking-wide leading-none select-none" id="astra-dpc-header-title">
                Astra DPC
              </h1>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6" id="desktop-nav">
            <button
              onClick={() => handleNav('home')}
              className={`flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeView === 'home'
                  ? 'text-maroon-500 bg-saffron-100/60'
                  : 'text-gray-600 hover:text-maroon-500 hover:bg-saffron-50'
              }`}
              id="nav-home-btn"
            >
              <Compass className="w-4 h-4" />
              <span>{t.home}</span>
            </button>

            <button
              onClick={onSearchToggle}
              className="flex items-center space-x-1.5 px-3 py-2 rounded-lg text-sm font-medium text-gray-600 hover:text-maroon-500 hover:bg-saffron-50 transition-colors"
              id="nav-search-btn"
            >
              <Search className="w-4 h-4" />
              <span>Search</span>
            </button>
          </nav>

          {/* Mobile Right Bar Actions */}
          <div className="flex md:hidden items-center space-x-2" id="mobile-quick-actions">
            <button
              onClick={onSearchToggle}
              className="p-2 text-gray-500 hover:text-maroon-500 rounded-lg"
              aria-label="Search"
              id="mobile-search-btn"
            >
              <Search className="w-5 h-5" />
            </button>

            {/* Mobile Hamburger menu toggle */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-maroon-500 hover:text-saffron-600 rounded-lg transition-colors focus:outline-none"
              id="mobile-hamburger-btn"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-spirit-bg border-b-2 border-saffron-100" id="mobile-drawer">
          <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3 shadow-inner">
            <button
              onClick={() => handleNav('home')}
              className="flex items-center space-x-2 w-full text-left px-4 py-3 rounded-lg text-base font-medium text-gray-700 hover:text-maroon-500 hover:bg-saffron-50 transition-colors"
              id="mobile-nav-home"
            >
              <Compass className="w-5 h-5 text-saffron-500" />
              <span>{t.home}</span>
            </button>

            <button
              onClick={() => {
                onSearchToggle();
                setMobileMenuOpen(false);
              }}
              className="flex items-center space-x-2 w-full text-left px-4 py-3 rounded-lg text-base font-medium text-gray-700 hover:text-maroon-500 hover:bg-saffron-50 transition-colors"
              id="mobile-nav-search"
            >
              <Search className="w-5 h-5 text-saffron-500" />
              <span>Search</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
}
