/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Search, X, BookOpen, FileText, ChevronRight } from 'lucide-react';
import { Language, Chapter, Verse } from '../types';
import { chapters, allVersesMap } from '../gita-data';
import { uiTranslations } from '../translations';

interface SearchBarProps {
  currentLang: Language;
  onNavigate: (view: 'home' | 'chapter' | 'verse', chapterId?: number, verseId?: number) => void;
  isOpen: boolean;
  onClose: () => void;
}

export function SearchBar({ currentLang, onNavigate, isOpen, onClose }: SearchBarProps) {
  const [query, setQuery] = useState('');
  const t = uiTranslations[currentLang];

  const searchResults = useMemo(() => {
    if (!query.trim()) return { chapters: [], verses: [] };

    const cleanQuery = query.toLowerCase().trim();

    // Search Chapters
    const matchedChapters = chapters.filter(ch => {
      return (
        ch.name.en.toLowerCase().includes(cleanQuery) ||
        ch.title.en.toLowerCase().includes(cleanQuery) ||
        ch.summary.en.toLowerCase().includes(cleanQuery)
      );
    });

    // Search Verses
    const matchedVerses: Verse[] = [];
    Object.keys(allVersesMap).forEach(key => {
      const v = allVersesMap[key];
      const matchInShloka = v.shloka.toLowerCase().includes(cleanQuery);
      const matchInTranslation = v.translation.en.toLowerCase().includes(cleanQuery);
      const matchInTransliteration = v.transliteration.en.toLowerCase().includes(cleanQuery);
      const matchInPurport = v.purport.en.toLowerCase().includes(cleanQuery);

      if (matchInShloka || matchInTranslation || matchInTransliteration || matchInPurport) {
        matchedVerses.push(v);
      }
    });

    return { chapters: matchedChapters, verses: matchedVerses };
  }, [query]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-black/50 backdrop-blur-sm flex justify-center p-4 sm:p-6 md:p-20" id="search-modal-container">
      <div 
        className="bg-spirit-bg w-full max-w-2xl rounded-2xl shadow-2xl border border-saffron-500/20 flex flex-col max-h-[80vh] overflow-hidden animate-in fade-in zoom-in duration-200"
        id="search-dialog"
      >
        {/* Search Input Box */}
        <div className="p-4 border-b border-saffron-100 flex items-center justify-between bg-saffron-50/50" id="search-input-header">
          <div className="flex items-center space-x-3 flex-1">
            <Search className="w-5 h-5 text-saffron-500 shrink-0" />
            <input
              type="text"
              autoFocus
              placeholder={t.searchPlaceholder}
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-transparent border-none text-gray-800 placeholder-gray-400 focus:outline-none text-base font-serif"
              id="search-input-field"
            />
          </div>
          <div className="flex items-center space-x-2">
            {query && (
              <button 
                onClick={() => setQuery('')}
                className="p-1 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-200"
                id="search-clear-btn"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            <button 
              onClick={onClose}
              className="p-1 px-3 text-sm font-semibold text-white bg-maroon-500 hover:bg-maroon-600 rounded-lg shadow-sm"
              id="search-close-btn"
            >
              Close
            </button>
          </div>
        </div>

        {/* Search Results Pane */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6" id="search-results-panel">
          {!query && (
            <div className="text-center py-10" id="search-init-screen">
              <BookOpen className="w-12 h-12 text-saffron-200 mx-auto mb-3" />
              <p className="text-gray-500 text-sm font-medium">
                {t.searchPlaceholder}
              </p>
              <div className="mt-4 flex flex-wrap justify-center gap-2">
                <span className="px-2 py-1 bg-saffron-100/50 text-saffron-800 rounded text-xs font-medium cursor-pointer" onClick={() => setQuery('Arjuna')}>Arjuna</span>
                <span className="px-2 py-1 bg-saffron-100/50 text-saffron-800 rounded text-xs font-medium cursor-pointer" onClick={() => setQuery('Karma')}>Karma</span>
                <span className="px-2 py-1 bg-saffron-100/50 text-saffron-800 rounded text-xs font-medium cursor-pointer" onClick={() => setQuery('Bhakti')}>Bhakti</span>
                <span className="px-2 py-1 bg-saffron-100/50 text-saffron-800 rounded text-xs font-medium cursor-pointer" onClick={() => setQuery('Dharma')}>Dharma</span>
                <span className="px-2 py-1 bg-saffron-100/50 text-saffron-800 rounded text-xs font-medium cursor-pointer" onClick={() => setQuery('Jnana')}>Jnana</span>
              </div>
            </div>
          )}

          {query && searchResults.chapters.length === 0 && searchResults.verses.length === 0 && (
            <div className="text-center py-10" id="search-empty-screen">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500 text-sm font-medium">
                {t.noResults}
              </p>
            </div>
          )}

          {query && (searchResults.chapters.length > 0 || searchResults.verses.length > 0) && (
            <div className="space-y-6" id="search-results-list">
              {/* Chapters Results */}
              {searchResults.chapters.length > 0 && (
                <div id="chapters-search-results">
                  <h3 className="text-xs font-bold text-saffron-800 uppercase tracking-widest border-b border-saffron-100 pb-2 mb-3">
                    {t.chapters} ({searchResults.chapters.length})
                  </h3>
                  <div className="space-y-2">
                    {searchResults.chapters.map((ch) => (
                      <div
                        key={ch.id}
                        onClick={() => {
                          onNavigate('chapter', ch.id);
                          onClose();
                        }}
                        className="group flex items-center justify-between p-3 rounded-xl bg-white border border-saffron-100 hover:border-saffron-500 hover:shadow-sm cursor-pointer transition-all"
                        id={`search-ch-result-${ch.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className="w-8 h-8 rounded-full bg-saffron-100 text-saffron-800 flex items-center justify-center font-bold text-sm">
                            {ch.id}
                          </div>
                          <div>
                            <p className="font-serif font-bold text-gray-800 group-hover:text-maroon-500 transition-colors">
                              {ch.name[currentLang]}
                            </p>
                            <p className="text-xs text-gray-400">
                              {ch.title[currentLang]} • {ch.verseCount} {t.verses}
                            </p>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-saffron-600 transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Verses Results */}
              {searchResults.verses.length > 0 && (
                <div id="verses-search-results">
                  <h3 className="text-xs font-bold text-saffron-800 uppercase tracking-widest border-b border-saffron-100 pb-2 mb-3">
                    {t.verses} ({searchResults.verses.length})
                  </h3>
                  <div className="space-y-2">
                    {searchResults.verses.map((v) => (
                      <div
                        key={`${v.chapterNumber}_${v.verseNumber}`}
                        onClick={() => {
                          onNavigate('verse', v.chapterNumber, v.verseNumber);
                          onClose();
                        }}
                        className="group flex items-center justify-between p-3 rounded-xl bg-white border border-saffron-100 hover:border-saffron-600 hover:shadow-sm cursor-pointer transition-all"
                        id={`search-v-result-${v.chapterNumber}-${v.verseNumber}`}
                      >
                        <div className="flex items-center space-x-3 overflow-hidden flex-1 mr-3">
                          <div className="w-8 h-8 rounded-full bg-maroon-50 text-maroon-700 flex items-center justify-center font-bold text-xs shrink-0">
                            {v.chapterNumber}.{v.verseNumber}
                          </div>
                          <div className="overflow-hidden">
                            <p className="font-serif font-bold text-gray-800 group-hover:text-maroon-500 transition-colors truncate">
                              {(v.transliteration[currentLang] || v.transliteration.en || '').split('\n')[0]}
                            </p>
                            <p className="text-xs text-gray-400 truncate">
                              {v.translation[currentLang] || v.translation.en || ''}
                            </p>
                          </div>
                        </div>
                        <ChevronRight className="w-5 h-5 text-gray-300 group-hover:text-saffron-600 transition-colors shrink-0" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
