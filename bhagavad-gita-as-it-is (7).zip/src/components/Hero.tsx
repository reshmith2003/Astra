/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Quote } from 'lucide-react';
import { Language } from '../types';
import { uiTranslations } from '../translations';

interface HeroProps {
  currentLang: Language;
  onExploreClick: () => void;
}

export function Hero({ currentLang, onExploreClick }: HeroProps) {
  const t = uiTranslations[currentLang];

  return (
    <div className="relative py-12 md:py-20 overflow-hidden bg-gradient-to-b from-saffron-50/70 via-spirit-bg to-spirit-bg border-b border-saffron-200/20" id="hero-banner">
      {/* Decorative Aura / Background glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[350px] sm:w-[500px] h-[350px] sm:h-[500px] rounded-full bg-radial from-saffron-200/20 to-transparent blur-3xl pointer-events-none" />

      <div className="max-w-4xl mx-auto px-4 text-center relative z-10">
        {/* Divine Spark */}
        <div className="inline-flex items-center space-x-1 bg-gradient-to-r from-maroon-100 to-saffron-100 text-maroon-700 px-4 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-6 sm:mb-8 border border-saffron-200/40 shadow-sm" id="divine-tag">
          <span>{t.authorLabel}</span>
        </div>

        {/* Lit Title */}
        <h2 className="text-4xl sm:text-5xl md:text-6xl font-serif font-black text-maroon-900 tracking-tight leading-tight mb-8 select-none">
          {t.appName}
        </h2>

        {/* Sacred Quote Card */}
        <div 
          className="mx-auto max-w-xl p-5 sm:p-6 md:p-8 rounded-2xl bg-white/70 backdrop-blur-sm border-2 border-dashed border-saffron-400/40 shadow-lg glow-saffron mb-10"
          id="sacred-quote-box"
        >
          <Quote className="w-8 h-8 text-saffron-400 mx-auto mb-3 opacity-60" />
          <p className="font-devanagari text-lg sm:text-xl md:text-2xl text-maroon-700 font-bold tracking-wide mb-3 leading-loose">
            {t.sanskritQuote}
          </p>
          <p className="text-gray-600 text-sm sm:text-base font-serif italic max-w-md mx-auto leading-relaxed">
            "{t.gitaQuote}"
          </p>
        </div>

        {/* Buttons */}
        <div className="flex flex-col sm:flex-row justify-center items-center gap-4">
          <button
            onClick={onExploreClick}
            className="w-full sm:w-auto px-8 py-4 rounded-xl text-base font-semibold text-white bg-gradient-to-r from-maroon-600 to-maroon-700 hover:from-saffron-600 hover:to-saffron-700 shadow-md hover:shadow-lg hover:-translate-y-0.5 cursor-pointer transition-all duration-300 flex items-center justify-center"
            id="explore-cta-btn"
          >
            <span>{t.readChapters}</span>
          </button>
        </div>
      </div>
    </div>
  );
}
