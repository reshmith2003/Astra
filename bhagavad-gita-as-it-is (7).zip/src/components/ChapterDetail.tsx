/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { ArrowLeft, Star, Sparkles } from 'lucide-react';
import { Language, Chapter } from '../types';
import { uiTranslations } from '../translations';
import { staticVerses } from '../gita-data';

interface ChapterDetailProps {
  chapter: Chapter;
  currentLang: Language;
  onBack: () => void;
  onVerseSelect: (verseId: number) => void;
}

export function ChapterDetail({
  chapter,
  currentLang,
  onBack,
  onVerseSelect,
}: ChapterDetailProps) {
  const t = uiTranslations[currentLang];

  // Helper to check if a verse is a primary static verse
  const isKeyVerse = (verseNum: number) => {
    return !!staticVerses[`${chapter.id}_${verseNum}`];
  };

  // Generate an array of 1 to verseCount
  const verses = Array.from({ length: chapter.verseCount }, (_, i) => i + 1);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-8" id="chapter-detail-container">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center space-x-2 text-sm font-semibold text-maroon-700 hover:text-saffron-600 cursor-pointer transition-colors mb-6 group border-b border-transparent hover:border-saffron-500 pb-0.5"
        id="back-to-chapters-btn"
      >
        <ArrowLeft className="w-4 h-4 transform group-hover:-translate-x-1 transition-transform" />
        <span>{t.allChapters}</span>
      </button>

      {/* Chapter Banner */}
      <div 
        className="bg-white rounded-3xl border border-saffron-200/60 overflow-hidden shadow-md glow-saffron p-6 sm:p-10 mb-10 text-center relative"
        id="chapter-banner-card"
      >
        <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-maroon-500 via-saffron-500 to-maroon-500 sacred-border" />
        
        <div className="max-w-3xl mx-auto">
          <span className="text-xs sm:text-sm font-mono font-black text-saffron-700 tracking-widest uppercase bg-saffron-50 px-3 py-1.5 rounded-full inline-block mb-3">
            {t.chapter} {chapter.id}
          </span>
          <h2 className="text-3xl sm:text-4xl font-serif font-black text-maroon-900 mb-2 leading-tight">
            {chapter.name[currentLang]}
          </h2>
          <p className="text-md sm:text-lg text-saffron-800 font-sans font-semibold mb-6">
            {chapter.title[currentLang]}
          </p>

          {/* Detailed Summary Box */}
          <div className="bg-saffron-50/50 p-6 rounded-2xl border border-saffron-100 text-left relative" id="chapter-intro bg">
            <h4 className="text-xs font-bold text-maroon-800 uppercase tracking-widest mb-2.5">
              {t.chapterSummary}
            </h4>
            <p className="text-gray-700 text-sm sm:text-base leading-relaxed">
              {chapter.summary[currentLang]}
            </p>
          </div>
        </div>
      </div>

      {/* Verses Subsection */}
      <div className="mb-12" id="chapter-verses-section">
        <div className="flex items-center space-x-2 mb-6 border-b border-saffron-100 pb-3">
          <h3 className="text-lg font-serif font-bold text-gray-900">
            {t.verseGridTitle}
          </h3>
          <span className="text-xs font-mono font-bold text-saffron-800 bg-saffron-100 px-2 py-0.5 rounded-md">
            {chapter.verseCount} {t.verses}
          </span>
        </div>

        {/* Verses selector grid */}
        <div className="grid grid-cols-2 min-[420px]:grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 xl:grid-cols-10 gap-2.5 sm:gap-4" id="verses-selection-grid">
          {verses.map((vNum) => {
            const isKey = isKeyVerse(vNum);
            return (
              <button
                key={vNum}
                onClick={() => onVerseSelect(vNum)}
                className={`relative group p-4 rounded-xl border text-center transition-all duration-300 cursor-pointer ${
                  isKey
                    ? 'bg-gradient-to-tr from-saffron-500/10 to-saffron-100/50 border-saffron-500/60 hover:border-saffron-600 hover:shadow-md hover:scale-[1.03]'
                    : 'bg-white border-saffron-200/50 hover:border-maroon-500 hover:shadow-sm hover:scale-[1.02]'
                }`}
                id={`verse-btn-${chapter.id}-${vNum}`}
              >
                {/* Special Indicator Badge for Key/Detailed offline verses */}
                {isKey && (
                  <span className="absolute -top-1.5 -right-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-saffron-500 text-white shadow-sm" title="Original Translation & Purport Available">
                    <Star className="h-2.5 w-2.5 fill-white" />
                  </span>
                )}

                <div className="text-xs font-mono text-gray-400 font-bold tracking-wide uppercase mb-1">
                  {t.verse}
                </div>
                <div className={`text-xl font-serif font-bold ${isKey ? 'text-saffron-900' : 'text-gray-800'}`}>
                  {chapter.id}.{vNum}
                </div>

                {isKey && (
                  <span className="text-[10px] text-saffron-700 font-bold bg-saffron-200/40 px-1.5 py-0.5 rounded uppercase mt-2.5 inline-block scale-95">
                    As It Is
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
