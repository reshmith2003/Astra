/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { ChaptersList } from './components/ChaptersList';
import { ChapterDetail } from './components/ChapterDetail';
import { VerseView } from './components/VerseView';
import { SearchBar } from './components/SearchBar';
import { Language, Verse } from './types';
import { chapters, getVerse } from './gita-data';

export default function App() {
  const language: Language = 'en';
  const [view, setView] = useState<'home' | 'chapter' | 'verse'>('home');
  const [selectedChapterId, setSelectedChapterId] = useState<number>(1);
  const [selectedVerseId, setSelectedVerseId] = useState<number>(1);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);

  // Active chapter lookup
  const activeChapter = chapters.find(ch => ch.id === selectedChapterId) || chapters[0];

  // Active verse lookup: loads instantly and authentic offline from the local combined dataset
  const activeVerse = getVerse(selectedChapterId, selectedVerseId);

  // Handle high level switching
  const handleNavigate = (
    newView: 'home' | 'chapter' | 'verse',
    chapterId?: number,
    verseId?: number
  ) => {
    setView(newView);
    if (chapterId !== undefined) {
      setSelectedChapterId(chapterId);
    }
    if (verseId !== undefined) {
      setSelectedVerseId(verseId);
    }
    window.scrollTo(0, 0);
  };

  // Nav: Next Verse with absolute boundary mapping
  const handleNextVerse = () => {
    const totalVersesInCurrentChapter = activeChapter.verseCount;

    if (selectedVerseId < totalVersesInCurrentChapter) {
      // Move to next verse in same chapter
      setSelectedVerseId(prev => prev + 1);
    } else {
      // End of this chapter, progress to next chapter
      if (selectedChapterId < 18) {
        setSelectedChapterId(prev => prev + 1);
        setSelectedVerseId(1);
      } else {
        // Wrap back to Chapter 1, Verse 1
        setSelectedChapterId(1);
        setSelectedVerseId(1);
      }
    }
    window.scrollTo(0, 0);
  };

  // Nav: Previous Verse with absolute boundary mapping
  const handlePrevVerse = () => {
    if (selectedVerseId > 1) {
      // Prev verse in same chapter
      setSelectedVerseId(prev => prev - 1);
    } else {
      // Verse 1 of chapter, regress to previous chapter
      if (selectedChapterId > 1) {
        const prevChapterId = selectedChapterId - 1;
        const prevChapter = chapters.find(ch => ch.id === prevChapterId)!;
        setSelectedChapterId(prevChapterId);
        setSelectedVerseId(prevChapter.verseCount);
      } else {
        // Wrap back to end of Chapter 18
        const finalChapter = chapters[17];
        setSelectedChapterId(18);
        setSelectedVerseId(finalChapter.verseCount);
      }
    }
    window.scrollTo(0, 0);
  };

  return (
    <div className="min-h-screen flex flex-col bg-spirit-bg flex-grow" id="app-root-container">
      {/* Global Navigation Header Bar */}
      <Header
        currentLang={language}
        onNavigate={handleNavigate}
        activeView={view}
        onSearchToggle={() => setSearchOpen(true)}
      />

      {/* Global Search Interface */}
      <SearchBar
        currentLang={language}
        onNavigate={handleNavigate}
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
      />

      {/* Central Screen Renderer */}
      <main className="flex-grow pb-16">
        {view === 'home' && (
          <div id="home-view-wrapper">
            <Hero 
              currentLang={language} 
              onExploreClick={() => {
                const element = document.getElementById('chapters-section');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }} 
            />
            <ChaptersList
              currentLang={language}
              onChapterClick={(id) => handleNavigate('chapter', id)}
            />
          </div>
        )}

        {view === 'chapter' && (
          <div id="chapter-view-wrapper">
            <ChapterDetail
              chapter={activeChapter}
              currentLang={language}
              onBack={() => handleNavigate('home')}
              onVerseSelect={(vNum) => handleNavigate('verse', selectedChapterId, vNum)}
            />
          </div>
        )}

        {view === 'verse' && (
          <div id="verse-view-wrapper">
            <VerseView
              verse={activeVerse}
              chapter={activeChapter}
              currentLang={language}
              onBackToChapter={() => handleNavigate('chapter', selectedChapterId)}
              onPrevVerse={handlePrevVerse}
              onNextVerse={handleNextVerse}
            />
          </div>
        )}
      </main>

      {/* Sacred Minimal Footer */}
      <footer className="bg-white border-t border-saffron-100 py-8 text-center" id="sacred-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <p className="font-devanagari text-lg text-maroon-600 font-bold tracking-widest mb-1.5">
            ॥ ॐ तत्सत् ॥
          </p>
          <p className="text-xs text-saffron-700 font-medium tracking-wider uppercase mb-3">
            Bhagavad Gita As It Is
          </p>
          <div className="h-px w-24 bg-gradient-to-r from-transparent via-saffron-300 to-transparent mx-auto mb-4" />
          <p className="text-[10px] text-gray-400 font-sans tracking-wide">
            Astradpc
          </p>
        </div>
      </footer>
    </div>
  );
}
